package pack;

public class A 
{
	public void show()
	{
		System.out.println("This is an example of protected access modifier");
	}

}
