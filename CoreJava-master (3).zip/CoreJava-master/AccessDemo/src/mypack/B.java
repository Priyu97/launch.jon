package mypack;
import pack.A;

public class B 
{
	public static void main(String[] args) 
	{
      A obj=new A();
      obj.show();

	}

}
