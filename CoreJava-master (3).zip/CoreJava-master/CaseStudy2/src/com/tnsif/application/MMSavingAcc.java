package com.tnsif.application;

import com.tnsif.framework.SavingAcc;

public class MMSavingAcc extends SavingAcc
{
	public MMSavingAcc(int AccNo, String accNm, float accBal,boolean isSalaried)
	{
		
	}
	

}
