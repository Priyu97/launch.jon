package com.tnsif.application;

public class MMCurrentAcc {

}
