package basics;

public class Main {

	public static void main(String[] args) {

		Main m=new Main();
		System.out.println(m instanceof Main);
	}

}
