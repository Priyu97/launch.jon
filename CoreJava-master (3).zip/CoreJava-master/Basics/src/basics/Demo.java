package basics;
class Super1
{
	void msg()
	{
		System.out.println("This is super1 class method");
	}	
}
class Super2
{
	void input()
	{
		System.out.println("This is super2 class method");
	}
}
 

