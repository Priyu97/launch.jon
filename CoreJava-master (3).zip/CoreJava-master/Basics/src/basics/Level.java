package basics;

enum Level {
	  LOW,
	  MEDIUM,
	  HIGH
	}