package mp;

public class Simple {

	public static void main(String[] args) {

		System.out.println("Welcome to packages");
	}

}
