package pack;

public class A {

	  public void msg()
	  {
		  System.out.println("Hello, welcome to TNS India Foundation");
	  }  

}
