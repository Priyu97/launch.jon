package com.tns.keyword;

final class A
{
	void run()
	{
		System.out.println("This is A class method");
	}
}

public class FinalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A obj=new A();
		obj.run();

	}

}
