package com.tns.basics;

public class ArrayDemo1 
{
	public static void main(String[] args) 
	{
		String[] bikes={"Avenger","Yezdi","Splender","BMW","Royal Enfield"};
		
		System.out.println(bikes[0]);

	}

}
