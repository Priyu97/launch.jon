package com.tns.basics;

public class ArithmeticOp
{
	public static void main(String[] args) 
	{
		int a=50,b=10;
		
		System.out.println("Addition of a and b is :"+(a+b));
		System.out.println("Subtraction of a and b is :"+(a-b));
		System.out.println("Multiplication of a and b is :"+(a*b));
		System.out.println("Division of a and b is :"+(a/b));
		System.out.println("Remainder of a and b is :"+(a%b));
		
	}

}
