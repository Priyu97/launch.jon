package com.tns.constructor;

public class Bike 
{
	Bike()
	{
		System.out.println("Bike sold...");
	}

	public static void main(String[] args) 
	{
		Bike b=new Bike(); 

	}

}
