package com.tns.instanceofEx;

public class DogEx 
{
	public static void main(String[] args) 
	{
		DogEx d=null;
		System.out.println(d instanceof DogEx);
		
	}

}
