package com.tns.wrapperclass;

public class WrapperExample2
{
	public static void main(String[] args) 
	{
	  Integer a=new Integer(3);
	  int i=a;
	  int j=a.intValue();
	  System.out.println(a);
	  System.out.println(i);
	  System.out.println(j);
	  

	}

}
