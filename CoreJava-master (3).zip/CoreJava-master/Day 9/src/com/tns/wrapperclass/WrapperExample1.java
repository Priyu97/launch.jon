package com.tns.wrapperclass;

public class WrapperExample1 
{
	public static void main(String[] args) 
	{
	  int a=20;
	  Integer i=a;
	  Integer j=Integer.valueOf(a);
	  
	  System.out.println(a);
	  System.out.println(i);
	  System.out.println(j);
	}
}
