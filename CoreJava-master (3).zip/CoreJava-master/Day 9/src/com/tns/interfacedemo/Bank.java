package com.tns.interfacedemo;

public interface Bank 
{
	float rateOfInterest();
}
