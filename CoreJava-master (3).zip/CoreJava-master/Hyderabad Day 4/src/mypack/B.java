package mypack;


public class B 
{
	public static void main(String[]args)
	{
		pack.A obj=new pack.A();
        obj.msg();
    }
}
