package pack;

 class A {
	 void msg()
	{
		System.out.println("Welcome to TNS India Foundation");
	}

}
