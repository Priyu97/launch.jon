package pack;

public class B1 {

	public static void main(String[]args)
	{
		A obj=new A();
		obj.msg();
	}
}
