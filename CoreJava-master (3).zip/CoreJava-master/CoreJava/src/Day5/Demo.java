package Day5;

 class Demo
 {
	private int data=23;
	private void msg()
	{
		System.out.println("Hello Java");
	}
 }
