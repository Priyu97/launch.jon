package String;

public class StringNewDemo 
{
	public static void main(String[] args)
	{
		
		String a=new String("Java");
		System.out.println(a);
		
		String b=new String("Java");
		System.out.println(b);
		
		a=a.concat("course");
		System.out.println(a);
		
		
		
		

	}

}
