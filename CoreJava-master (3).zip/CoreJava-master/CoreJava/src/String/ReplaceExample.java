package String;
public class ReplaceExample
{  
public static void main(String args[])
{  
String s1="TNS India Foundation";  
String replaceString=s1.replace('a','O');  
System.out.println(replaceString);  
}}  