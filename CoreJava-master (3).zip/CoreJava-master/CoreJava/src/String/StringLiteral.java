package String;

public class StringLiteral 
{
	public static void main(String[]args)
	{
		String a="Java";//literal
		System.out.println(a);
		
		String b="Java";
		System.out.println(b);
		
		a=a.concat("Programming");
		System.out.println(a);
	}

}
