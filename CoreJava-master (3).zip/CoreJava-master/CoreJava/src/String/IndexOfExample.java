package String;

public class IndexOfExample
{  
    public static void main(String[] args)
    {  
        String s1 = "This is indexOf method";             
        int index = s1.indexOf("method");   
        System.out.println("index of substring "+index);          
    }  
  
}  