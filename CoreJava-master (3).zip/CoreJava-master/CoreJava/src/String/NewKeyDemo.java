package String;

public class NewKeyDemo {

	public static void main(String[] args) 
	{
		String a=new String("Java");
		System.out.println(a);
		
		String b=new String("Java");
		System.out.println(b);
		
		a=a.concat("Programming");
		System.out.println(a);
		
	}

}
