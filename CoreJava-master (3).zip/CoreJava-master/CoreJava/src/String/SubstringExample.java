package String;

public class SubstringExample
{  
public static void main(String args[])
{  
String s1="Fullstack";  
  
System.out.println(s1.substring(2));  
}
}  