package String;

public class LengthExample
{  
public static void main(String args[])
{  
String s1="Java Course";  
String s2="python";  
System.out.println("string length is: "+s1.length());  
System.out.println("string length is: "+s2.length());  
}}  