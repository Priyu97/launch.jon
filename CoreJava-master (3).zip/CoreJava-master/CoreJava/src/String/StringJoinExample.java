package String;

public class StringJoinExample
{  
public static void main(String args[])
{  
String joinString1=String.join("@","welcome","to","TNS India Founadtion","org");  
System.out.println(joinString1);  
}}  