package String;

public class EndsWithExample
	{  
	  public static void main(String args[])
	  	{  
		  String s1="TNS India Foundation";  
		  System.out.println(s1.endsWith("a"));  
		  System.out.println(s1.endsWith("n"));  
}
}  	