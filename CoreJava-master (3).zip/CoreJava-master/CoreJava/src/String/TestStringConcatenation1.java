package String;

public class TestStringConcatenation1
{  
	 public static void main(String args[])
	 {  
		   String s="Core"+" Java";  
		   System.out.println(s);  
     }  
}  