package String;

public class Teststringcomparison1 
{ 
		 public static void main(String args[])
		 {  
		   String s1="Divya";  
		   String s2="Divya";  
		   String s3=new String("Divya");  
		   String s4="Bhavani";  
		   System.out.println(s1.equals(s2)); 
		   System.out.println(s1.equals(s3));
		   System.out.println(s1.equals(s4));
		 }  
		}  

