package String;

public class TestSubstring
{    
	 public static void main(String args[])
	 {    
		 String s="InformationTechnology";   
		 
		 System.out.println("Original String: " + s);  
		 System.out.println("Substring starting from index 6: " +s.substring(6));
		 System.out.println("Substring starting from index 0 to 6: "+s.substring(0,6));  
	 }  
}    