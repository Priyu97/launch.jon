package String;

public class IsEmptyExample
{  
public static void main(String args[])
{  
String s1="";  
String s2="JavaFullStack"; 

System.out.println(s1.isEmpty());  
System.out.println(s2.isEmpty());  
}
}  
