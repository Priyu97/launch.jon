package String;

public class LastIndexOfExample
{  
public static void main(String args[])
{  
String s1="this is index of example";  
int index1=s1.lastIndexOf('i');  
System.out.println(index1);  
}
}