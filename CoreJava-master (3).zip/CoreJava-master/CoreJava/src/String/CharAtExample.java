package String;

public class CharAtExample
{  
	public static void main(String args[])
	{  
		String name="JavaFullStack";  
		char ch=name.charAt(4);  
		System.out.println(ch);  
	}
}  