package String;

public class TestStringConcatenation2
{  
	 public static void main(String args[])
	 {  
		   String s1="Peter ";  
		   String s2="Parkar"; 
		   
		   String s3=s1.concat(s2);  
		   System.out.println(s3);  
		  }  
		}  