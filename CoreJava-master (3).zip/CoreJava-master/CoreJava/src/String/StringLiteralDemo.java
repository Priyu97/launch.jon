package String;

public class StringLiteralDemo 
{
	public static void main(String[]args)
	{
		String a="Java";
		System.out.println(a);
		
		String b="Java";
		System.out.println(b);
		
		a=a.concat("Course");
		System.out.println(a);
		
		
		
		
	}

}
