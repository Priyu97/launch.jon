package com.tns.variables;


class Demo
{
	 static int value=100;
	
	 void show()
	{
		System.out.println("This is static method");
	}
}

public class MultiStatic 
{
	public static void main(String[]args)
	{
		
		System.out.println(Demo.value);
		d.show();
	}

}
