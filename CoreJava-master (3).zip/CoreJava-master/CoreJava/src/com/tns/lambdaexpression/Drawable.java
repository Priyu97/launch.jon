package com.tns.lambdaexpression;

public interface Drawable 
{
	public void draw();

}
