package Encapsulation;

public class Student
{
	private String name;
	//getter
	public String getName()
	{
		return name;
	}
    //setter
	public void setName(String name)
	{
		this.name=name;
	}

}
