package WrapperClass;


//int to Interger

public class WrapperExample1 {

	public static void main(String[] args) {
		
		int a=10;
		Integer b=a;
		Integer i=Integer.valueOf(a);
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(i);

	}

}
