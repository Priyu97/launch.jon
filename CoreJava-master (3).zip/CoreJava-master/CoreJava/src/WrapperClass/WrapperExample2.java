package WrapperClass;

public class WrapperExample2 {

	public static void main(String[] args) {
		
		//Integer to int
		
		Integer a=new Integer(5);
		int j=a;
		int i=a.intValue();
		
		System.out.println(j);
		System.out.println(i);

	}

}
