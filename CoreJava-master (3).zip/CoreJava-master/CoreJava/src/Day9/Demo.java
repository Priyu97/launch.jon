package Day9;

class A //super1
{
	void show()
	{
		System.out.println("This is super class1 ");
	}
}
class B //Super2
{
	void show()
	{
		System.out.println("This is super class2");
	}
}
/*public class Demo extends A,B{
	
	Demo d=new Demo();
	d.show();
	}*/


