package Day9;

public interface Client1
{
  	void input();
    void output();
}

