package JUnit;

public class Calculator {

	public static Integer add(int i, int j) {
		// TODO Auto-generated method stub
		return i+j;
	}

}