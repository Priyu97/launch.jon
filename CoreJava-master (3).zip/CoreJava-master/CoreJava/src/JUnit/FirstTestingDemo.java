package JUnit;

import org.junit.jupiter.api.Test;

public class FirstTestingDemo {

	
	@Test
	void display()
	{
		System.out.println("Hello");
	
	}

	@Test
	void display2()
	{
		System.out.println("Hello All");
	
	}
}
