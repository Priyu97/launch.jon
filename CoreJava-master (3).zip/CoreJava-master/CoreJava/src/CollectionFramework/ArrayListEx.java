package CollectionFramework;

import java.util.*;

public class ArrayListEx 
{
	public static void main(String[] args) 
	{
	 ArrayList<String> list=new ArrayList<String>();
	 
	 list.add("Avenger");
	 list.add("YEZDI");
	 list.add("Jawa");
	 list.add("Honda");
	 list.add("R15");
	 
	 System.out.println(list);

	}

}
