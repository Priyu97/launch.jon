package CollectionFramework;
import java.util.*;

public class LinkedHashSet {

	public static void main(String[] args) {
		
		LinkedHashSet<String> l=new LinkedHashSet<String>();
		
		l.add("TNS");
		l.add("India");
		l.add("Foundation");
		

	}

	public void add(String string) {
		// TODO Auto-generated method stub
		
	}

	public Iterator<String> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

}
