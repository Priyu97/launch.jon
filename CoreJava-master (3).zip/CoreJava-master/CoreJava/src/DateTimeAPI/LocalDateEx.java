package DateTimeAPI;

import java.time.LocalDate;

public class LocalDateEx 
{
  public static void main(String[] args) 
  {
    LocalDate myObj = LocalDate.now(); 
    System.out.println(myObj); 
  }
}