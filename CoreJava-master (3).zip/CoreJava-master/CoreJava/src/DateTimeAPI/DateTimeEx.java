package DateTimeAPI;

import java.time.LocalDateTime; 

public class DateTimeEx 
{
	  public static void main(String[] args)
	  {
	    LocalDateTime myObj = LocalDateTime.now();
	    System.out.println(myObj);
	  }
	}


