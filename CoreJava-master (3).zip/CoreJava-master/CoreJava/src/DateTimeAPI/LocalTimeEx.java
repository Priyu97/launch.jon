package DateTimeAPI;

import java.time.LocalTime;

	public class LocalTimeEx 
	{
	  public static void main(String[] args) 
	  {
	    LocalTime myObj = LocalTime.now();
	    System.out.println(myObj);
	  }
	}

