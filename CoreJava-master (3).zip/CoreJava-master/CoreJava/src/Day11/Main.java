package Day11;

public class Main {

	public static void main(String[] args) {
		
		String []cars= {"Volvo","BWM","Audi","Ford","Kia"};
		
		for(String i : cars)
		{
			System.out.println(i);
		}

	}

}
