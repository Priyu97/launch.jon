package com.tns.basic;

public class AssignOp 
{
	public static void main(String[] args) 
	{
	  int a=10,b=5,c=15,d=250,e=200;
	  
	  a+=3;//a=a+3=10+3=13
	  System.out.println(a);
	  
	  b-=2;//b=b-2=5-2=3
	  System.out.println(b);
	  
	  c*=60;//c=c*60=15*60=
	  System.out.println(c);
	  
	  d/=10;//d=d/10
	  System.out.println(d);
	  
	  e%=100;//e=e%100=
	  System.out.println(e);

	}

}
