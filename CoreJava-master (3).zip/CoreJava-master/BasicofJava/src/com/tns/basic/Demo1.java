package com.tns.basic;

public class Demo1 
{
	public static void main(String[] args) 
	{
		int myNum=10;
		System.out.println(myNum);
		

	}

}
