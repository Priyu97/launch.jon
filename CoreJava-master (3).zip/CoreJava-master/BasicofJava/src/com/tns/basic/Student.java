package com.tns.basic;

public class Student 
{
	int id;
	String name;
	
public static void main(String[]args)
{
	Student s=new Student();
	s.id=1;
	s.name="Tom";
	System.out.println(s.id);
	System.out.println(s.name);
}
}
