package com.tns.basic;

public class Demo 
{
	public static void main(String[] args) 
	{
		String name="John";
		System.out.println(name);
	}

}
