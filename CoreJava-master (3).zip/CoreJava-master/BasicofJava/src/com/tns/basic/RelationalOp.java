package com.tns.basic;

public class RelationalOp 
{
	public static void main(String[] args) 
	{
	  int num1=12,num2=4;
	  
	  //is equal to
	  System.out.println("num1==num2 :"+(num1==num2));
	  
	  //is not equal to
	  System.out.println("num1!=num2 :"+(num1!=num2));
	  
	  //Greater than
	  System.out.println("num1>num2 :"+(num1>num2));
	  
	  //Less than
	  System.out.println("num1<num2 :"+(num1<num2));
	  
	  //Greater than or equal to
	  System.out.println("num1>=num2 :"+(num1>=num2));
	  
	  //Less than or equal to
	  System.out.println("num1<=num2 :"+(num1<=num2));

	}

}
