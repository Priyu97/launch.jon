package com.tns.basic;

public class ArrayDemo1
{
	public static void main(String[] args) 
	{

    String[] bikes={"Avenger","KTM","YEZDI","Royal Enfield","Splender"};
    
    for(String i:bikes)
    {
    	System.out.println(i);
    }

	}
}
