package com.tns.basic;

public class PreMethodDemo 
{
	public static void main(String[] args) 
	{
		System.out.print("Hello, welcome to TNS");

	}

}
