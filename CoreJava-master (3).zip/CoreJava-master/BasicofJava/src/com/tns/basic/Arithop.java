package com.tns.basic;

public class Arithop 
{
	public static void main(String[] args)
	{
		int num1=50,num2=10;
		
		System.out.println("Addition of num1 and num2 is:"+(num1+num2));
		System.out.println("Subtraction of num1 and num2 is:"+(num1-num2));
		System.out.println("Multiplication of num1 and num2 is:"+(num1*num2));
		System.out.println("Division of num1 and num2 is:"+(num1/num2));
		System.out.println("Mod of num1 and num2 is:"+(num1%num2));
	}
}
