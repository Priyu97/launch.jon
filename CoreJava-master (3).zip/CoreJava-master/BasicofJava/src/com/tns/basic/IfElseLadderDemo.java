package com.tns.basic;

public class IfElseLadderDemo 
{
	public static void main(String[] args)
	{
		String city="Hyderabad";
		
		if(city=="Hyderabad")
		{
			System.out.println("Your city is Hyderabad");
		}
		else if(city=="Delhi")
		{
			System.out.println("Your city is Delhi");
		}
		else if(city=="Nashik")
		{
			System.out.println("Your city is Nashik");
		}
		else
		{
			System.out.println(city);
		}

	}

}
