package com.tns.basic;

public class Demo2 
{
	public static void main(String[] args) 
	{
	  int m=60;
	  int minutePerHour=50;
	  
	  System.out.println(m);
	  System.out.println(minutePerHour);

	}

}
