package p1;

public class Demo1 {
	public void input()
	{
		System.out.println("This is public modifier");
	}

}
