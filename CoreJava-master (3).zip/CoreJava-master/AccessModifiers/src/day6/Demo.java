package day6;


class A
{
	 int x=10; //private
}

public class Demo {

	public static void main(String[] args) {
		
		A obj=new A();
		System.out.println(obj.x);

	}

}
