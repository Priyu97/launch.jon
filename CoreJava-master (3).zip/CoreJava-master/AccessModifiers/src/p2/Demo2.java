package p2;
import p1.*;

 class Demo2  
 {
	public static void main(String[]args)
	{
		Demo1 obj=new Demo1();
		obj.input();
	}
	

}
