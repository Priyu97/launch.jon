package com.tns.datetimeapi;

import java.time.LocalTime;

public class CurrentTimeDemo
{
	public static void main(String[] args) 
	{
	  LocalTime obj=LocalTime.now();
	  System.out.println(obj);
	}
}
