package com.tns.datetimeapi;

import java.time.LocalDate;

public class CurrentDateDemo 
{
	public static void main(String[] args) 
	{
	   LocalDate ld= LocalDate.now();
	   System.out.println(ld);
	}
}
