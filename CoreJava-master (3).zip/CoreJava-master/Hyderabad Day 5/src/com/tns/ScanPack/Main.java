package com.tns.ScanPack;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
	  Scanner sc=new Scanner(System.in);
	  
	  System.out.println("Enter your name :");
	  
	  String n=sc.nextLine();
	  System.out.println("Welocme "+n+" in TNS India Foundation.");

	}

}
