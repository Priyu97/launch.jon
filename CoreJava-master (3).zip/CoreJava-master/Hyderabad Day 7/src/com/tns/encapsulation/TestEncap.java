package com.tns.encapsulation;

public class TestEncap 
{
	public static void main(String[] args)
	{
		Student s=new Student();
		s.setName("Chandana");
		System.out.println(s.getName());

	}

}
