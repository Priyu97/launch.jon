package com.tns.basic;

public class AssignOP 
{
	public static void main(String[] args)
	{
		int a=10,b=20,c=30,d=40,e=50;
		a+=10;
		System.out.println("The value of a is:"+a);
		b-=10;
		System.out.println("The value of b is:"+b);
		c*=10;
		System.out.println("The value of c is:"+c);
		d/=20;
		System.out.println("The value of d is:"+d);
		e%=10;
		System.out.println("The value of e is:"+e);

	}

}
