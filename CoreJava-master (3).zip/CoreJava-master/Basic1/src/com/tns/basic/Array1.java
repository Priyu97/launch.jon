package com.tns.basic;
public class Array1 
{
	public static void main(String[] args) 
	{
	String bikes[]={"BMW","KTM","Royal Enfield","JAWA","YEZDI"};
    for(String i:bikes)
    {
    	System.out.println(i);
    }
	}
}
