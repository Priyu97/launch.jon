package com.tns.basic;

public class Demo1 
{
	public static void main(String[] args)
	{
		int m=50;
		int minutePerSecond=60;
		
		System.out.println(m);
		System.out.println(minutePerSecond);

	}

}
