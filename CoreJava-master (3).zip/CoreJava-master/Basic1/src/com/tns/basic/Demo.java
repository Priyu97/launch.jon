package com.tns.basic;

public class Demo 
{

	public static void main(String[] args) 
	{
		int x=10;
		
		System.out.println(x);

	}

}
