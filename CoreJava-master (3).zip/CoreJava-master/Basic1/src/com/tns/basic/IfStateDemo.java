package com.tns.basic;

public class IfStateDemo 
{
	public static void main(String[] args) 
	{
		int x=10,y=12;
		
		if(x+y<20)
		{
			System.out.println("Addition of x and y is greater than 20 ");
		}
	
	}
}
