package com.tns.basic;

public class RelationalOp
{
	public static void main(String[] args) 
	{
		int num1=12,num2=4;
		
		System.out.println("num1==num2 :"+(num1==num2));
		System.out.println("num1!=num2 :"+(num1!=num2));
		System.out.println("num1>num2 :"+(num1>num2));
		System.out.println("num1<num2 :"+(num1<num2));
		System.out.println("num1>=num2 :"+(num1>=num2));
		System.out.println("num1<=num2 :"+(num1<=num2));

	}

}
