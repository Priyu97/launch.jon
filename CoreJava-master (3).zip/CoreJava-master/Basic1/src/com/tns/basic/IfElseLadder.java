package com.tns.basic;

public class IfElseLadder 
{
	public static void main(String[] args) 
	{
		String city="Mumbai";
		if(city=="Delhi")
		{
			System.out.println("Your city is Delhi");
		}
		else if(city=="Nashik")
		{
			System.out.println("Your city is Nashik");
		}
		else if(city=="Pune")
		{
			System.out.println("Your city is Pune");
		}
		else
		{
			System.out.println(city);
		}
	

	}

}
