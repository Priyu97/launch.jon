package com.tns.constructor;

public class Simple 
{
	public static void main(String[] args) 
	{
		Simple s=new Simple();
		System.out.println(s instanceof Simple);

	}

}
